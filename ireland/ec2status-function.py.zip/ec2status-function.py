import boto3
import json
import random
import time
from pprint import pprint
dynamodb = boto3.client('dynamodb')

def lambda_handler(event, context):
    # TODO implement
    client = boto3.client("ec2")
    status = client.describe_instance_status(IncludeAllInstances = True)
    # print(status['InstanceStatuses'][0]['InstanceState']['Name'])
    
    for i in status["InstanceStatuses"]:
        x = random.randint(1,30)
        t1=int(time.time())+86400
        print("InstanceId :", i["InstanceId"])
        s2=i['InstanceState']['Name']
        dynamodb.put_item(TableName='ec2-status',Item={'random':{"N":str(x)},'InstanceId':{'S':i["InstanceId"]},'InstanceState':{'S':s2},'timetolive':{'N':str(t1)}})
